# Bot MD5 Python — Brain Self Evolution

Bot Tài/Xỉu tự học mẫu cầu, tự tạo algorithm, có thể push lên GitHub.

## Cấu trúc

```
bot-md5-python/
├── main.py
├── config.py
├── requirements.txt
├── Procfile
├── runtime.txt
├── brain/
│   ├── brain_core.py      # Brain trung tâm
│   ├── evolution.py       # Tự phát hiện + quản lý algorithms
│   ├── github_sync.py     # Commit/push generated + memory
│   └── discovery.py
├── core/
│   ├── ensemble.py
│   ├── fetch.py
│   └── state.py
├── modules/               # Module hỗ trợ
├── generated/
│   └── algorithms.json    # Algorithm do Brain tự tạo
└── memory/
    └── brain_memory.json
```

## Chạy local

```bash
pip install -r requirements.txt
export MD5_API_TOKEN=your_token
python main.py
```

## Deploy Railway

1. Push repo lên GitHub
2. Railway → New Project → Deploy from GitHub
3. Variables:
   - `MD5_API_TOKEN` = token API
   - `AUTO_GIT_PUSH` = `true` (nếu muốn Brain tự commit algorithm mới)
4. (Optional) Thêm GitHub token / deploy key nếu bật AUTO_GIT_PUSH

## API

- `GET /` — trạng thái + brain stats
- `GET /api/bot/status` — dự đoán hiện tại
- `GET /api/bot/brain` — thống kê algorithm

## Cơ chế Evolution

1. Mỗi ván → Brain ghi pattern vào `memory/`
2. Pattern đủ mẫu (≥30) + confidence tốt → tạo algorithm trong `generated/algorithms.json`
3. Algorithm thắng nhiều → tăng weight; thua nhiều → disable
4. Nếu `AUTO_GIT_PUSH=true` → commit + push → Railway redeploy
