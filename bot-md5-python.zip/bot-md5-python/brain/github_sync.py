"""
GitHub Sync — commit + push generated/ và memory/ lên GitHub
để Railway có thể auto-redeploy khi có algorithm mới.
"""
import os
import subprocess
from typing import Dict


class GitHubSync:
    def __init__(self):
        self.enabled = os.getenv("AUTO_GIT_PUSH", "false").lower() == "true"

    def run(self, command: str) -> str:
        result = subprocess.run(
            command,
            shell=True,
            text=True,
            capture_output=True,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr or result.stdout or "git command failed")
        return result.stdout

    def sync(self, message: str) -> Dict:
        if not self.enabled:
            return {"status": "disabled"}

        try:
            self.run("git config user.name 'Brain Auto Evolution'")
            self.run("git config user.email 'brain@localhost'")
            self.run("git add generated/ memory/")

            status = self.run("git status --porcelain")
            if not status.strip():
                return {"status": "nothing_to_commit"}

            # Escape message an toàn
            safe_msg = message.replace('"', "'")[:120]
            self.run(f'git commit -m "{safe_msg}"')
            self.run("git push origin HEAD")

            return {"status": "pushed", "message": safe_msg}
        except Exception as e:
            print(f"⚠️ GitHub sync lỗi: {e}")
            return {"status": "error", "error": str(e)}
