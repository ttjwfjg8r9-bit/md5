"""
Ensemble — kết hợp Brain (tự học) + các module hỗ trợ
"""
from typing import List, Dict, Any

from brain import Brain

# Module hỗ trợ (không bắt buộc, có thể tắt)
try:
    from modules.deepseek import analyze as deepseek_analyze
except Exception:
    deepseek_analyze = None

try:
    from modules.hybrid import analyze as hybrid_analyze
except Exception:
    hybrid_analyze = None

try:
    from modules.markov_dice import analyze as markov_analyze
except Exception:
    markov_analyze = None

try:
    from modules.soi_cau_pro import analyze as soi_cau_analyze
except Exception:
    soi_cau_analyze = None

brain = Brain()

WEIGHTS = {
    "brain": 2.20,
    "deepseek": 1.60,
    "hybrid": 1.45,
    "markov": 1.40,
    "soiCau": 1.45,
}


def _outcomes(history: List[dict]) -> List[str]:
    return [h["outcome"] for h in history if h.get("outcome")]


def ensemble_predict(history: List[dict]) -> Dict[str, Any]:
    if len(history) < 10:
        return {
            "pred": None,
            "confidence": 0,
            "reason": f"Warmup {len(history)}/10",
            "active": 0,
        }

    outs = _outcomes(history)
    scores = {"TAI": 0.0, "XIU": 0.0}
    reasons = []
    active = 0
    signals = []

    # 1. Brain (chính)
    try:
        br = brain.think(outs)
        if br and br.get("pred"):
            w = WEIGHTS["brain"]
            s = float(br.get("score", 1.5)) * w
            scores[br["pred"]] += s
            reasons.append(br.get("reason", "Brain"))
            signals.append({"name": "brain", **br})
            active += 1
    except Exception as e:
        print("Brain lỗi:", e)

    # 2. Các module hỗ trợ
    helpers = [
        ("deepseek", deepseek_analyze),
        ("hybrid", hybrid_analyze),
        ("markov", markov_analyze),
        ("soiCau", soi_cau_analyze),
    ]
    for name, fn in helpers:
        if fn is None:
            continue
        try:
            res = fn(history)
            if not res or not res.get("pred"):
                continue
            w = WEIGHTS.get(name, 1.0)
            s = float(res.get("score", 1.0)) * w
            scores[res["pred"]] += s
            reasons.append(res.get("reason", name))
            signals.append({"name": name, **res})
            active += 1
        except Exception as e:
            print(f"Module {name} lỗi:", e)

    if scores["TAI"] == 0 and scores["XIU"] == 0:
        recent = outs[-6:]
        tai = recent.count("TAI")
        if tai >= 4:
            pred = "XIU"
        elif tai <= 2:
            pred = "TAI"
        else:
            pred = "XIU" if outs[-1] == "TAI" else "TAI"
        return {
            "pred": pred,
            "confidence": 52,
            "reason": "Fallback",
            "active": 0,
            "signals": [],
        }

    pred = "TAI" if scores["TAI"] > scores["XIU"] else "XIU"
    diff = abs(scores["TAI"] - scores["XIU"])
    conf = min(50 + diff * 6 + active * 2.5, 90)

    return {
        "pred": pred,
        "confidence": round(conf),
        "reason": " | ".join(reasons[:3]) + f" | {active} modules",
        "active": active,
        "scores": scores,
        "signals": signals,
        "brain_stats": brain.stats(),
    }


def record_feedback(history: List[dict], actual: str):
    """Gọi sau mỗi ván để Brain học."""
    outs = _outcomes(history)
    # history hiện tại chưa chứa outcome mới → outs là các ván trước
    brain.learn(outs, actual)
